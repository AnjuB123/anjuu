package com.infy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.infy.dto.ProductDTO;
import com.infy.service.ProductServiceImpl;

@SpringBootApplication
public class DemoOnSpringDataApplication implements CommandLineRunner{

	@Autowired
	ProductServiceImpl  productServiceImpl;
	
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringDataApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		addProductDetails();
	}

	
	public void addProductDetails() {
		
		//create Dto object with product details
		
		ProductDTO pdto = new ProductDTO();
		//pdto.setPid(1001);
		pdto.setPname("keyboard");
		pdto.setPrice(800);
		pdto.setMobileNo(34353);
		
		productServiceImpl.addProduct(pdto);;
		
		System.out.println("record is inserted");
		
		
	}
	
	
	
}
