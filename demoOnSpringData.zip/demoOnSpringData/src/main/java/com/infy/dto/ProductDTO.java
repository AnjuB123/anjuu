package com.infy.dto;

public class ProductDTO {

	  
		private Integer pid;
		private String pname;
	    private float price;
	    private Integer mobileNo;
	    
	    
		public Integer getPid() {
			return pid;
		}
		public void setPid(Integer pid) {
			this.pid = pid;
		}
		public String getPname() {
			return pname;
		}
		public void setPname(String pname) {
			this.pname = pname;
		}
		public float getPrice() {
			return price;
		}
		public void setPrice(float price) {
			this.price = price;
		}
		public Integer getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(Integer mobileNo) {
			this.mobileNo = mobileNo;
		}
		
		
		
		
	}


