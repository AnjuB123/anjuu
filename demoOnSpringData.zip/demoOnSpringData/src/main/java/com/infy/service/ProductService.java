package com.infy.service;

import com.infy.dto.ProductDTO;

public interface ProductService {
        
	public void addProduct(ProductDTO pdto);
	
	
	
}
