package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.ProductDTO;
import com.infy.entity.Product;
import com.infy.repo.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepository productRepository; //has a relation
	

	@Override
	public void addProduct(ProductDTO pdto) {
		
		//covert the ProductDto into Product entity class object
		Product pd = new Product();
		pd.setPid(pdto.getPid());
		pd.setPname(pdto.getPname());
        pd.setPrice(pdto.getPrice());
        pd.setMobileNo(pdto.getMobileNo());
        
        //
        productRepository.save(pd); //internally it will convert into insert query.
		
	}

}
